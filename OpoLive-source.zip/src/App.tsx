import { useState, useEffect, useRef } from "react";

// ─── SVG ORNATE FRAMES ────────────────────────────────────────────────────────

/** Wings with rank number badge — top of room cards */
function WingsBadge({ rank, color = "#d4a017" }: { rank: number; color?: string }) {
  return (
    <svg width="110" height="44" viewBox="0 0 110 44" fill="none">
      {/* left wing */}
      <path d="M54 22 C40 10,18 6,4 14 C14 14,26 16,30 24 C20 20,10 22,6 28 C16 24,28 24,34 30 C26 28,18 32,16 38 C26 30,38 28,44 34 Z"
        fill={color} opacity="0.92" />
      {/* right wing mirror */}
      <path d="M56 22 C70 10,92 6,106 14 C96 14,84 16,80 24 C90 20,100 22,104 28 C94 24,82 24,76 30 C84 28,92 32,94 38 C84 30,72 28,66 34 Z"
        fill={color} opacity="0.92" />
      {/* center shield */}
      <ellipse cx="55" cy="24" rx="14" ry="14" fill={color} />
      <ellipse cx="55" cy="24" rx="11" ry="11" fill="url(#ws1)" />
      <text x="55" y="29" textAnchor="middle" fontSize="13" fontWeight="900" fill="#fff"
        fontFamily="Outfit,sans-serif">{rank}</text>
      <defs>
        <radialGradient id="ws1" cx="40%" cy="35%">
          <stop offset="0%" stopColor="#fff4" />
          <stop offset="100%" stopColor={color + "00"} />
        </radialGradient>
      </defs>
    </svg>
  );
}

/** Ornate corner for frames */
function OrnateCorner({ color, size = 28 }: { color: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <path d="M2 30 L2 10 Q2 2 10 2 L30 2" stroke={color} strokeWidth="2.5" strokeLinecap="round" fill="none" />
      <circle cx="2" cy="30" r="2.5" fill={color} />
      <circle cx="30" cy="2" r="2.5" fill={color} />
      <circle cx="8" cy="8" r="1.5" fill={color} opacity="0.6" />
      <path d="M6 24 Q6 6 24 6" stroke={color} strokeWidth="1" opacity="0.4" fill="none" strokeLinecap="round" />
    </svg>
  );
}

/** 3D Coin */
function Coin3D({ size = 44, spin = false }: { size?: number; spin?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none"
      className={spin ? "animate-spin-slow" : ""}>
      <ellipse cx="28" cy="28" rx="25" ry="25" fill="url(#c3d_outer)" />
      <ellipse cx="28" cy="26" rx="21" ry="21" fill="url(#c3d_mid)" />
      <ellipse cx="28" cy="25" rx="16" ry="16" fill="url(#c3d_inner)" />
      <text x="28" y="31" textAnchor="middle" fontSize="14" fontWeight="900"
        fill="#7a4a00" fontFamily="Outfit,sans-serif">★</text>
      <ellipse cx="20" cy="19" rx="5" ry="3.5" fill="white" opacity="0.3"
        transform="rotate(-30 20 19)" />
      <defs>
        <radialGradient id="c3d_outer" cx="38%" cy="32%">
          <stop offset="0%" stopColor="#ffe87a" />
          <stop offset="55%" stopColor="#d4a017" />
          <stop offset="100%" stopColor="#6b3d00" />
        </radialGradient>
        <radialGradient id="c3d_mid" cx="38%" cy="32%">
          <stop offset="0%" stopColor="#ffd700" />
          <stop offset="100%" stopColor="#b8860b" />
        </radialGradient>
        <radialGradient id="c3d_inner" cx="38%" cy="32%">
          <stop offset="0%" stopColor="#fff5a0" />
          <stop offset="100%" stopColor="#e0a800" />
        </radialGradient>
      </defs>
    </svg>
  );
}

/** Gift box 3D */
function GiftBox({ size = 38 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 60 60" fill="none">
      <rect x="8" y="26" width="44" height="26" rx="3" fill="url(#gb_body)" />
      <rect x="6" y="18" width="48" height="11" rx="3" fill="url(#gb_lid)" />
      <rect x="26" y="18" width="8" height="34" fill="url(#gb_rib)" />
      <rect x="6" y="22" width="48" height="7" fill="url(#gb_rib)" opacity="0.85" />
      <ellipse cx="20" cy="17" rx="9" ry="5" fill="url(#gb_rib)" transform="rotate(-20 20 17)" opacity="0.9" />
      <ellipse cx="40" cy="17" rx="9" ry="5" fill="url(#gb_rib)" transform="rotate(20 40 17)" opacity="0.9" />
      <circle cx="30" cy="18" r="4" fill="#ff2d8b" />
      <ellipse cx="17" cy="28" rx="5" ry="3" fill="white" opacity="0.15" transform="rotate(-15 17 28)" />
      <defs>
        <linearGradient id="gb_body" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#7c2d12" />
          <stop offset="100%" stopColor="#431407" />
        </linearGradient>
        <linearGradient id="gb_lid" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#9a3412" />
          <stop offset="100%" stopColor="#7c2d12" />
        </linearGradient>
        <linearGradient id="gb_rib" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#fde047" />
          <stop offset="100%" stopColor="#ca8a04" />
        </linearGradient>
      </defs>
    </svg>
  );
}

// ─── Top Header ───────────────────────────────────────────────────────────────
type PageTab = "mine" | "party" | "events";

function TopHeader({ active, onSelect }: { active: PageTab; onSelect: (t: PageTab) => void }) {
  return (
    <div className="relative overflow-hidden" style={{ background: "#f5f0e8" }}>
      {/* Palace/Taj Mahal silhouette background */}
      <div className="absolute inset-0 opacity-20">
        <svg viewBox="0 0 390 72" width="390" height="72" fill="none" preserveAspectRatio="xMidYMid slice">
          {/* Simplified Taj Mahal/mosque silhouette */}
          <rect x="0" y="40" width="390" height="32" fill="#8B6914" />
          {/* Center dome */}
          <ellipse cx="195" cy="30" rx="28" ry="26" fill="#8B6914" />
          <rect x="183" y="30" width="24" height="20" fill="#8B6914" />
          {/* Left dome */}
          <ellipse cx="135" cy="38" rx="18" ry="16" fill="#8B6914" />
          <rect x="123" y="38" width="24" height="12" fill="#8B6914" />
          {/* Right dome */}
          <ellipse cx="255" cy="38" rx="18" ry="16" fill="#8B6914" />
          <rect x="243" y="38" width="24" height="12" fill="#8B6914" />
          {/* Left minarets */}
          <rect x="70" y="18" width="8" height="40" fill="#8B6914" />
          <ellipse cx="74" cy="18" rx="6" ry="8" fill="#8B6914" />
          <rect x="100" y="28" width="6" height="28" fill="#8B6914" />
          <ellipse cx="103" cy="28" rx="5" ry="6" fill="#8B6914" />
          {/* Right minarets */}
          <rect x="312" y="18" width="8" height="40" fill="#8B6914" />
          <ellipse cx="316" cy="18" rx="6" ry="8" fill="#8B6914" />
          <rect x="284" y="28" width="6" height="28" fill="#8B6914" />
          <ellipse cx="287" cy="28" rx="5" ry="6" fill="#8B6914" />
        </svg>
      </div>

      <div className="relative flex items-center justify-between px-4 pt-3 pb-2">
        {/* Tabs */}
        <div className="flex items-center gap-5">
          {([
            { key: "mine" as PageTab, label: "Mine" },
            { key: "party" as PageTab, label: "Party" },
            { key: "events" as PageTab, label: "Events" },
          ]).map((t) => (
            <button
              key={t.key}
              onClick={() => onSelect(t.key)}
              className="relative flex flex-col items-center pb-1"
            >
              <span
                style={{
                  fontFamily: "Outfit, sans-serif",
                  fontWeight: t.key === active ? 800 : 500,
                  fontSize: t.key === "events" ? 16 : 15,
                  color: t.key === active ? "#1a6b2a" : "#888",
                  fontStyle: t.key === "events" ? "italic" : "normal",
                  letterSpacing: t.key === "events" ? -0.3 : 0,
                }}
              >
                {t.label}
                {t.key === "events" && (
                  <span className="inline-block w-2 h-2 rounded-full bg-red-500 ml-0.5 align-top mt-0.5" />
                )}
              </span>
              {t.key === active && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
                  style={{ background: "#1a6b2a" }} />
              )}
            </button>
          ))}
        </div>

        {/* Right icons */}
        <div className="flex items-center gap-3">
          {/* Calendar icon */}
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg,#d4a017,#b8860b)", boxShadow: "0 2px 8px #d4a01755" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="4" width="18" height="17" rx="2" fill="white" opacity="0.9" />
              <path d="M16 2v4M8 2v4M3 10h18" stroke="#d4a017" strokeWidth="2" strokeLinecap="round" />
              <path d="M7 14h2M11 14h2M15 14h2M7 18h2M11 18h2" stroke="#d4a017" strokeWidth="1.5" strokeLinecap="round" />
              <path d="M8 6H4a1 1 0 00-1 1v1h18V7a1 1 0 00-1-1h-4" stroke="#d4a017" strokeWidth="0" fill="#d4a01733" />
            </svg>
          </div>
          {/* House icon */}
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg,#b8860b,#8B6914)", boxShadow: "0 2px 8px #b8860b55" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
              <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" fill="white" opacity="0.9" />
              <path d="M9 22V12h6v10" fill="#b8860b" />
            </svg>
          </div>
          {/* Search/magnifier */}
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg,#2d7a3a,#1a5c28)", boxShadow: "0 2px 8px #2d7a3a55" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <circle cx="11" cy="11" r="7" stroke="white" strokeWidth="2.5" />
              <path d="M20 20l-3.5-3.5" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Banner Carousel ──────────────────────────────────────────────────────────
const BANNERS = [
  {
    id: 1,
    hindi: "अपग्रेड करें",
    hindi2: "सिक्के पाएं",
    bg: "from-[#1e0040] via-[#3b0070] to-[#0a0020]",
    coinColor: "#ffd700",
  },
  {
    id: 2,
    hindi: "डायमंड पाएं",
    hindi2: "रोज़ लॉगिन करें",
    bg: "from-[#001a40] via-[#003070] to-[#000a20]",
    coinColor: "#60a5fa",
  },
  {
    id: 3,
    hindi: "गिफ्ट भेजें",
    hindi2: "पुरस्कार जीतें",
    bg: "from-[#001a10] via-[#00400a] to-[#000a00]",
    coinColor: "#4ade80",
  },
];

function BannerCarousel() {
  const [idx, setIdx] = useState(0);
  const t = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => {
    t.current = setTimeout(() => setIdx((p) => (p + 1) % BANNERS.length), 4000);
    return () => clearTimeout(t.current);
  }, [idx]);
  const b = BANNERS[idx];

  return (
    <div className="mx-3 mt-2 relative rounded-2xl overflow-hidden" style={{ height: 148 }}>
      <div className={`absolute inset-0 bg-gradient-to-br ${b.bg}`} />

      {/* Coin scatter — background */}
      {[
        { x: 12, y: 10, s: 36, r: -20, o: 0.7 },
        { x: 52, y: 52, s: 28, r: 15, o: 0.5 },
        { x: 4, y: 68, s: 32, r: 10, o: 0.65 },
        { x: 280, y: 8, s: 42, r: 25, o: 0.8 },
        { x: 320, y: 55, s: 34, r: -15, o: 0.7 },
        { x: 290, y: 100, s: 28, r: 5, o: 0.55 },
        { x: 240, y: 20, s: 30, r: -10, o: 0.5 },
        { x: 340, y: 20, s: 22, r: 30, o: 0.4 },
      ].map((c, i) => (
        <div key={i} className="absolute pointer-events-none"
          style={{ left: c.x, top: c.y, transform: `rotate(${c.r}deg)`, opacity: c.o }}>
          <Coin3D size={c.s} />
        </div>
      ))}

      {/* Purple/gold gem accent */}
      <div className="absolute top-3 right-20 pointer-events-none">
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
          <polygon points="14,2 26,10 22,24 6,24 2,10" fill="#7c3aed" opacity="0.9" />
          <polygon points="14,5 22,11 19,22 9,22 6,11" fill="#a855f7" />
          <polygon points="14,8 18,13 16,20 12,20 10,13" fill="#c084fc" />
          <ellipse cx="12" cy="10" rx="3" ry="2" fill="white" opacity="0.35" transform="rotate(-20 12 10)" />
        </svg>
      </div>

      {/* Hindi text — center */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-center">
          <div style={{
            fontFamily: "'Outfit',sans-serif",
            fontWeight: 900,
            fontSize: 34,
            lineHeight: 1.15,
            background: `linear-gradient(180deg, #ffe87a 0%, ${b.coinColor} 50%, #b8860b 100%)`,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            textShadow: "none",
            filter: "drop-shadow(0 2px 8px #00000088)",
          }}>
            {b.hindi}
          </div>
          <div style={{
            fontFamily: "'Outfit',sans-serif",
            fontWeight: 900,
            fontSize: 34,
            lineHeight: 1.15,
            background: `linear-gradient(180deg, #ffe87a 0%, ${b.coinColor} 50%, #b8860b 100%)`,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            filter: "drop-shadow(0 2px 8px #00000088)",
          }}>
            {b.hindi2}
          </div>
        </div>
      </div>

      {/* Dot indicators */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="rounded-full transition-all duration-300"
            style={{
              width: i === idx ? 20 : 7,
              height: 7,
              background: i === idx ? "#fff" : "#ffffff55",
            }} />
        ))}
      </div>
    </div>
  );
}

// ─── Ranking Cards ────────────────────────────────────────────────────────────
function RankingCards() {
  return (
    <div className="flex gap-2 mx-3 mt-3">
      {/* Room Ranking — red/gold frame */}
      <RankCard
        title="Room Ranking"
        frameGrad="linear-gradient(160deg,#7c1010,#3d0000)"
        borderColor="#d4a017"
        topColor="#d4a017"
        topDeco="🏆"
        avatars={[
          "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=80&h=80&fit=crop",
          "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&h=80&fit=crop",
          "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=80&h=80&fit=crop",
        ]}
        bgAccent="rgba(180,30,0,0.5)"
      />
      {/* CP Ranking — purple/pink frame */}
      <RankCard
        title="CP Ranking"
        frameGrad="linear-gradient(160deg,#4a0070,#2d0050)"
        borderColor="#c026d3"
        topColor="#f0abfc"
        topDeco="💑"
        avatars={[
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop",
          "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop",
        ]}
        showHeart
        bgAccent="rgba(140,0,180,0.5)"
      />
      {/* Family — green/gold frame */}
      <RankCard
        title="Family"
        frameGrad="linear-gradient(160deg,#0a3d12,#051a08)"
        borderColor="#22c55e"
        topColor="#4ade80"
        topDeco="👨‍👩‍👧"
        avatars={[
          "https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=80&h=80&fit=crop",
        ]}
        familyBadge
        bgAccent="rgba(0,80,20,0.5)"
      />
    </div>
  );
}

function RankCard({
  title, frameGrad, borderColor, topColor, topDeco,
  avatars, showHeart, familyBadge, bgAccent,
}: {
  title: string;
  frameGrad: string;
  borderColor: string;
  topColor: string;
  topDeco: string;
  avatars: string[];
  showHeart?: boolean;
  familyBadge?: boolean;
  bgAccent: string;
}) {
  return (
    <div className="flex-1 relative rounded-xl overflow-hidden"
      style={{
        background: frameGrad,
        border: `2px solid ${borderColor}`,
        boxShadow: `0 0 16px ${borderColor}55, inset 0 0 20px ${bgAccent}`,
        minHeight: 120,
      }}>
      {/* Ornate top band */}
      <div className="absolute top-0 left-0 right-0 h-1"
        style={{ background: `linear-gradient(90deg,transparent,${borderColor},transparent)` }} />

      {/* Corner flourishes */}
      <div className="absolute top-1 left-1"><OrnateCorner color={borderColor} size={16} /></div>
      <div className="absolute top-1 right-1" style={{ transform: "scaleX(-1)" }}><OrnateCorner color={borderColor} size={16} /></div>

      {/* Emoji deco top center */}
      <div className="flex justify-center pt-2">
        <span style={{ fontSize: 12 }}>{topDeco}</span>
      </div>

      {/* Avatars area */}
      <div className="flex justify-center items-center mt-1 px-1 gap-1">
        {familyBadge ? (
          <div className="relative">
            {/* Rockstar family style badge */}
            <div className="w-16 h-14 rounded-lg flex items-center justify-center"
              style={{ background: "#000", border: "2px solid #22c55e" }}>
              <div className="text-center">
                <div style={{ fontFamily: "Outfit", fontWeight: 900, fontSize: 7, color: "#fff", letterSpacing: 0.5 }}>ROCKSTAR</div>
                <div style={{ fontFamily: "Outfit", fontWeight: 900, fontSize: 9, color: "#ffd700" }}>MALIK</div>
              </div>
            </div>
            {/* small avatar bottom right */}
            {avatars[0] && (
              <img src={avatars[0]} alt="" className="w-7 h-7 rounded-full object-cover absolute -bottom-1 -right-1 border-2"
                style={{ borderColor }} />
            )}
          </div>
        ) : showHeart ? (
          <div className="relative w-20 h-14">
            {avatars[0] && (
              <img src={avatars[0]} alt="" className="w-11 h-11 rounded-full object-cover absolute left-0 top-0 border-2"
                style={{ borderColor, boxShadow: `0 0 8px ${borderColor}77` }} />
            )}
            {/* heart */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10"
              style={{ fontSize: 14, filter: "drop-shadow(0 0 4px #f0abfc)" }}>❤️</div>
            {avatars[1] && (
              <img src={avatars[1]} alt="" className="w-11 h-11 rounded-full object-cover absolute right-0 top-0 border-2"
                style={{ borderColor, boxShadow: `0 0 8px ${borderColor}77` }} />
            )}
          </div>
        ) : (
          <div className="relative w-20 h-14">
            {/* Stacked 3 avatars */}
            {avatars.slice(0, 3).map((a, i) => (
              <img key={i} src={a} alt="" className="w-9 h-9 rounded-full object-cover absolute border-2"
                style={{
                  borderColor,
                  left: i === 0 ? 0 : i === 1 ? "50%" : "auto",
                  right: i === 2 ? 0 : "auto",
                  top: i === 1 ? 0 : 10,
                  transform: i === 1 ? "translateX(-50%)" : "none",
                  zIndex: 3 - i,
                  boxShadow: `0 0 8px ${borderColor}55`,
                }} />
            ))}
          </div>
        )}
      </div>

      {/* Title */}
      <div className="text-center pb-2 pt-1">
        <span style={{ fontFamily: "Outfit", fontWeight: 800, fontSize: 10, color: topColor, letterSpacing: 0.3 }}>{title}</span>
      </div>

      {/* Bottom ornate band */}
      <div className="absolute bottom-0 left-0 right-0 h-1"
        style={{ background: `linear-gradient(90deg,transparent,${borderColor},transparent)` }} />
    </div>
  );
}

// ─── Filter Pills ─────────────────────────────────────────────────────────────
function FilterPills({ active, onSelect }: { active: "popular" | "new"; onSelect: (v: "popular" | "new") => void }) {
  return (
    <div className="flex items-center gap-3 mx-3 mt-4">
      <button
        onClick={() => onSelect("popular")}
        className="flex items-center gap-1.5 px-5 py-2 rounded-full font-black text-sm transition-all"
        style={{
          fontFamily: "Outfit",
          background: active === "popular"
            ? "linear-gradient(135deg,#1a5c28,#0d3318)"
            : "transparent",
          color: active === "popular" ? "#fff" : "#9ca3af",
          border: active === "popular" ? "none" : "1.5px solid #d1fae533",
          boxShadow: active === "popular" ? "0 4px 14px #1a5c2866" : "none",
        }}
      >
        🔥 Popular
      </button>
      <button
        onClick={() => onSelect("new")}
        className="px-5 py-2 rounded-full font-black text-sm transition-all"
        style={{
          fontFamily: "Outfit",
          background: active === "new"
            ? "linear-gradient(135deg,#1a5c28,#0d3318)"
            : "transparent",
          color: active === "new" ? "#fff" : "#9ca3af",
          border: active === "new" ? "none" : "1.5px solid #d1fae533",
          boxShadow: active === "new" ? "0 4px 14px #1a5c2866" : "none",
        }}
      >
        New
      </button>
    </div>
  );
}

// ─── Room Cards ───────────────────────────────────────────────────────────────
const ROOMS = [
  {
    id: 1,
    rank: 1,
    frameColor: "#d4a017",
    frameDark: "#7c2d12",
    frameGrad: "linear-gradient(160deg,#5c0000,#2a0000)",
    borderGrad: "linear-gradient(180deg,#d4a017,#7a3010,#d4a017)",
    badgeLabel: "New",
    badgeBg: "#22c55e",
    img: "https://images.unsplash.com/photo-1571266028243-d220c6a7bd47?w=400&h=300&fit=crop",
    hostName: "●Never😶",
    micCount: 4,
    flags: "🇮🇳",
    displayName: "●Never😶❤️●One...",
    levelBadge: null,
    wingColor: "#d4a017",
    wingAccent: "#ff4444",
  },
  {
    id: 2,
    rank: 2,
    frameColor: "#3b82f6",
    frameDark: "#1e3a8a",
    frameGrad: "linear-gradient(160deg,#0a2060,#050a30)",
    borderGrad: "linear-gradient(180deg,#3b82f6,#1e3a8a,#3b82f6)",
    badgeLabel: "Lv.3",
    badgeBg: "#3b82f6",
    img: "https://images.unsplash.com/photo-1516914943479-89db7d9ae7f2?w=400&h=300&fit=crop",
    hostName: "❤ ilent bo...",
    micCount: null,
    flags: "🇮🇳",
    displayName: "Fake people, st...",
    levelBadge: "Lv.3",
    coinCount: "15000",
    wingColor: "#3b82f6",
    wingAccent: "#d4a017",
  },
];

function RoomGrid({ rooms, onEnter }: { rooms: typeof ROOMS; onEnter: () => void }) {
  return (
    <div className="grid grid-cols-2 gap-2.5 mx-3 mt-3">
      {rooms.map((room) => (
        <OrnateRoomCard key={room.id} room={room} onEnter={onEnter} />
      ))}
    </div>
  );
}

function OrnateRoomCard({ room, onEnter }: { room: typeof ROOMS[0]; onEnter: () => void }) {
  const fc = room.frameColor;
  return (
    <div className="relative rounded-2xl overflow-visible" style={{ paddingTop: 16 }}>
      {/* Wing badge — sits above card */}
      <div className="absolute -top-2 left-1/2 -translate-x-1/2 z-20">
        <WingsBadge rank={room.rank} color={room.wingColor} />
      </div>

      <div
        className="relative rounded-xl overflow-hidden"
        style={{
          background: room.frameGrad,
          border: `2.5px solid ${fc}`,
          boxShadow: `0 0 20px ${fc}55, inset 0 0 20px ${fc}11`,
        }}
      >
        {/* Top ornate band */}
        <div style={{ height: 3, background: `linear-gradient(90deg,transparent,${fc},transparent)` }} />

        {/* Corner ornaments */}
        <div className="absolute top-3 left-2 z-10"><OrnateCorner color={fc} size={16} /></div>
        <div className="absolute top-3 right-2 z-10" style={{ transform: "scaleX(-1)" }}><OrnateCorner color={fc} size={16} /></div>

        {/* Room photo */}
        <div className="relative" style={{ height: 130 }}>
          <img src={room.img} alt={room.hostName} className="w-full h-full object-cover"
            style={{ filter: "brightness(0.7) saturate(1.2)" }} />
          <div className="absolute inset-0"
            style={{ background: "linear-gradient(180deg,transparent 50%,rgba(0,0,0,0.8) 100%)" }} />

          {/* New/Level badge */}
          <div className="absolute top-2 left-2">
            <div className="flex items-center gap-0.5 px-2 py-0.5 rounded-full"
              style={{ background: room.badgeBg, boxShadow: `0 0 8px ${room.badgeBg}88` }}>
              {room.badgeLabel !== "New" && <span style={{ fontSize: 9 }}>🎯</span>}
              <span style={{ fontFamily: "Outfit", fontWeight: 800, fontSize: 9, color: "#fff" }}>{room.badgeLabel}</span>
            </div>
          </div>

          {/* Coin count (room 2) */}
          {"coinCount" in room && room.coinCount && (
            <div className="absolute bottom-2 right-2 flex items-center gap-1 px-2 py-0.5 rounded-full"
              style={{ background: "#d4a017", boxShadow: "0 0 10px #d4a01788" }}>
              <Coin3D size={12} />
              <span style={{ fontFamily: "Outfit", fontWeight: 900, fontSize: 10, color: "#0f0f1a" }}>{room.coinCount}</span>
            </div>
          )}

          {/* Host name + mic bar */}
          <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
            <span style={{ fontFamily: "Nunito", fontWeight: 700, fontSize: 10, color: "#fff" }}>
              {room.hostName}
            </span>
            {room.micCount !== null && (
              <div className="flex items-center gap-1">
                <span style={{ fontSize: 9, color: "#ffffffaa" }}>iii</span>
                <span style={{ fontFamily: "Outfit", fontWeight: 700, fontSize: 10, color: "#fff" }}>{room.micCount}</span>
              </div>
            )}
          </div>
        </div>

        {/* Bottom info row */}
        <div className="px-2 py-2 flex items-center gap-1.5"
          style={{ background: `linear-gradient(180deg,${room.frameDark}aa,#000000cc)` }}>
          <span style={{ fontSize: 12 }}>{room.flags}</span>
          <div className="w-6 h-6 rounded-full overflow-hidden border border-white/30 shrink-0">
            <img src="https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=40&h=40&fit=crop"
              alt="" className="w-full h-full object-cover" />
          </div>
          <span className="text-xs font-bold truncate"
            style={{ fontFamily: "Nunito", color: "#ffffffcc", fontSize: 9 }}>{room.displayName}</span>
        </div>

        {/* Bottom ornate band */}
        <div style={{ height: 3, background: `linear-gradient(90deg,transparent,${fc},transparent)` }} />

        {/* Enter Room button */}
        <button
          onClick={onEnter}
          className="w-full py-2 font-black text-xs tracking-wide"
          style={{
            fontFamily: "Outfit",
            background: `linear-gradient(135deg,${fc},${room.frameDark})`,
            color: room.rank === 1 ? "#0f0f1a" : "#fff",
            boxShadow: `0 4px 16px ${fc}55`,
            letterSpacing: 0.5,
          }}
        >
          🎙️ Enter Room
        </button>
      </div>
    </div>
  );
}

// ─── Family Room Row ──────────────────────────────────────────────────────────
function FamilyRoomRow() {
  return (
    <div className="mx-3 mt-3 flex flex-col gap-2">
      {/* Praveen Family */}
      <div className="flex items-center gap-3 p-3 rounded-xl"
        style={{ background: "#0d1a0d", border: "1px solid #22c55e22" }}>
        {/* Circular family photo frame */}
        <div className="relative shrink-0">
          <div className="w-16 h-16 rounded-full overflow-hidden border-2"
            style={{ borderColor: "#d4a017", boxShadow: "0 0 12px #d4a01755" }}>
            <img src="https://images.unsplash.com/photo-1546961342-ea5f62d9a6b6?w=120&h=120&fit=crop"
              alt="Praveen Family" className="w-full h-full object-cover" />
          </div>
          {/* PRAVEEN FAMILY label below */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 whitespace-nowrap">
            <span style={{ fontFamily: "Outfit", fontWeight: 800, fontSize: 7, color: "#d4a017", letterSpacing: 0.3 }}>PRAVEEN</span>
            <br />
            <span style={{ fontFamily: "Outfit", fontWeight: 800, fontSize: 7, color: "#d4a017", letterSpacing: 0.3, display: "block", textAlign: "center" }}>FAMILY</span>
          </div>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0 ml-2">
          <div className="flex items-center gap-1 mb-1">
            <span style={{ fontSize: 10 }}>🇮🇳</span>
            <span style={{ fontFamily: "Outfit", fontWeight: 900, fontSize: 12 }}>
              <span style={{ color: "#c026d3" }}>P</span>
              <span style={{ color: "#fff" }}>raveen</span>
              {" "}
              <span style={{ color: "#22c55e" }}>F</span>
              <span style={{ color: "#fff" }}>amily</span>
              {" "}
              <span style={{ color: "#fff", fontSize: 10 }}>∞</span>
            </span>
          </div>
          {/* Member avatar row */}
          <div className="flex items-center gap-1 mb-1.5">
            <img src="https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=40&h=40&fit=crop"
              alt="" className="w-5 h-5 rounded-full object-cover border border-white/30" />
            <span style={{ fontFamily: "Nunito", fontSize: 9, color: "#ffffffaa" }}>Αικδηύ ✧·°</span>
          </div>
          {/* Badge row */}
          <div className="flex items-center gap-1">
            <div className="px-1.5 py-0.5 rounded"
              style={{ background: "linear-gradient(135deg,#7c3aed,#4c1d95)" }}>
              <span style={{ fontFamily: "Outfit", fontWeight: 800, fontSize: 8, color: "#fff" }}>VIP2</span>
            </div>
            {["⭐", "💎", "👑", "🔥", "🌙"].map((e, i) => (
              <span key={i} style={{ fontSize: 11 }}>{e}</span>
            ))}
            <div className="ml-1 flex items-center gap-0.5">
              <span style={{ fontSize: 9, color: "#ffffffaa" }}>iii</span>
              <span style={{ fontFamily: "Outfit", fontWeight: 700, fontSize: 10, color: "#fff" }}>3</span>
            </div>
          </div>
        </div>

        {/* Receive gift button */}
        <div className="shrink-0 flex flex-col items-center gap-0.5">
          <GiftBox size={36} />
          <div className="px-2 py-0.5 rounded-full"
            style={{ background: "linear-gradient(135deg,#d4a017,#b8860b)", boxShadow: "0 0 8px #d4a01766" }}>
            <span style={{ fontFamily: "Outfit", fontWeight: 800, fontSize: 9, color: "#0f0f1a" }}>receive</span>
          </div>
        </div>
      </div>

      {/* Second room row */}
      <div className="flex items-center gap-3 p-3 rounded-xl"
        style={{ background: "#0d1a0d", border: "1px solid #22c55e22" }}>
        <div className="w-14 h-14 rounded-xl overflow-hidden shrink-0"
          style={{ border: "2px solid #d4a01755" }}>
          <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop"
            alt="" className="w-full h-full object-cover" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-1">
            <span style={{ fontSize: 12 }}>🇮🇳</span>
            <span style={{ fontFamily: "Nunito", fontWeight: 700, fontSize: 12, color: "#fff" }}>
              AaO muje piyar k?
            </span>
          </div>
          <div className="flex items-center gap-1 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
            <span style={{ fontFamily: "Outfit", fontSize: 9, color: "#ffffffaa" }}>Live • 2.1K</span>
          </div>
        </div>
        <button className="px-3 py-1.5 rounded-full font-bold text-xs"
          style={{ background: "linear-gradient(135deg,#22c55e,#15803d)", color: "#fff", fontFamily: "Outfit" }}>
          Join
        </button>
      </div>
    </div>
  );
}

// ─── Bottom Navigation ────────────────────────────────────────────────────────
type NavKey = "party" | "discover" | "center" | "message" | "my";

/** Mosque/palace icon for Party tab */
function MosqueIcon({ active }: { active: boolean }) {
  const c = active ? "#d4a017" : "#6b7280";
  return (
    <svg width="30" height="30" viewBox="0 0 48 48" fill="none">
      {/* Base */}
      <rect x="4" y="32" width="40" height="14" rx="2" fill={c} opacity={active ? 1 : 0.5} />
      {/* Center dome */}
      <ellipse cx="24" cy="22" rx="11" ry="11" fill={c} />
      <rect x="13" y="22" width="22" height="12" fill={c} />
      {/* Side wings */}
      <rect x="4" y="26" width="10" height="8" rx="1" fill={c} opacity="0.8" />
      <rect x="34" y="26" width="10" height="8" rx="1" fill={c} opacity="0.8" />
      {/* Minarets */}
      <rect x="6" y="18" width="5" height="16" rx="1" fill={c} />
      <ellipse cx="8.5" cy="18" rx="3.5" ry="5" fill={c} />
      <rect x="37" y="18" width="5" height="16" rx="1" fill={c} />
      <ellipse cx="39.5" cy="18" rx="3.5" ry="5" fill={c} />
      {/* Crescent on dome */}
      {active && <path d="M20 15 A6 6 0 1 0 28 15 A4 4 0 1 1 20 15" fill="#fff" opacity="0.6" />}
    </svg>
  );
}

/** Genie lamp icon for Discover */
function LampIcon({ active }: { active: boolean }) {
  const c = active ? "#d4a017" : "#6b7280";
  return (
    <svg width="28" height="28" viewBox="0 0 48 48" fill="none">
      {/* Smoke top */}
      <path d="M24 4 Q20 8 24 12 Q28 16 24 20" stroke={c} strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.7" />
      {/* Lamp body */}
      <path d="M8 30 Q6 24 14 22 L34 22 Q42 22 40 30 Q38 38 24 40 Q10 38 8 30Z" fill={c} opacity={active ? 1 : 0.6} />
      {/* Spout */}
      <path d="M34 22 Q44 18 46 24 Q44 28 36 28" fill={c} opacity="0.8" />
      {/* Handle */}
      <path d="M8 26 Q2 28 4 34 Q6 40 12 38" stroke={c} strokeWidth="3" strokeLinecap="round" fill="none" />
      {/* Shine */}
      <ellipse cx="18" cy="27" rx="5" ry="3" fill="white" opacity="0.25" transform="rotate(-20 18 27)" />
    </svg>
  );
}

/** Envelope with gift for Message */
function MessageIcon({ active, count }: { active: boolean; count?: number }) {
  const c = active ? "#d4a017" : "#6b7280";
  return (
    <div className="relative">
      <svg width="28" height="28" viewBox="0 0 48 48" fill="none">
        <rect x="4" y="12" width="40" height="28" rx="4" fill={c} opacity={active ? 1 : 0.6} />
        <path d="M4 16 L24 28 L44 16" stroke={active ? "#0f0f1a" : "#374151"} strokeWidth="2.5" strokeLinecap="round" />
        {/* Little gift on top */}
        <rect x="19" y="6" width="10" height="10" rx="1" fill="#d4a017" stroke="#b8860b" strokeWidth="1" />
        <rect x="23" y="6" width="2" height="10" fill="#b8860b" />
        <rect x="19" y="10" width="10" height="2" fill="#b8860b" />
        <path d="M22 7 Q24 4 26 7" stroke="#b8860b" strokeWidth="1" fill="none" />
      </svg>
      {count && (
        <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center"
          style={{ background: "#ef4444", border: "2px solid #0d1a0d" }}>
          <span style={{ fontFamily: "Outfit", fontSize: 9, fontWeight: 800, color: "#fff" }}>{count}</span>
        </div>
      )}
    </div>
  );
}

/** Crescent moon for Profile */
function MoonIcon({ active }: { active: boolean }) {
  const c = active ? "#d4a017" : "#6b7280";
  return (
    <svg width="26" height="26" viewBox="0 0 48 48" fill="none">
      <path d="M30 8 A18 18 0 1 0 30 40 A14 14 0 1 1 30 8Z" fill={c} opacity={active ? 1 : 0.6} />
      {active && (
        <>
          <circle cx="34" cy="14" r="2.5" fill="white" opacity="0.5" />
          <circle cx="38" cy="24" r="1.5" fill="white" opacity="0.4" />
        </>
      )}
    </svg>
  );
}

function BottomNav({ active, onSelect }: { active: NavKey; onSelect: (k: NavKey) => void }) {
  return (
    <div className="fixed bottom-0 left-1/2 -translate-x-1/2 z-50 w-full" style={{ maxWidth: 390 }}>
      <div
        className="flex items-center justify-around px-4 py-3"
        style={{
          background: "linear-gradient(180deg,#0a2010,#061508)",
          borderTop: "2px solid #22c55e44",
          boxShadow: "0 -4px 32px #000c",
        }}
      >
        {/* Party */}
        <button onClick={() => onSelect("party")} className="flex flex-col items-center gap-0.5">
          <MosqueIcon active={active === "party"} />
          <span style={{ fontFamily: "Outfit", fontWeight: 700, fontSize: 9, color: active === "party" ? "#d4a017" : "#6b7280" }}>Party</span>
        </button>

        {/* Discover */}
        <button onClick={() => onSelect("discover")} className="flex flex-col items-center gap-0.5">
          <LampIcon active={active === "discover"} />
          <span style={{ fontFamily: "Outfit", fontWeight: 700, fontSize: 9, color: active === "discover" ? "#d4a017" : "#6b7280" }}>Discover</span>
        </button>

        {/* Center 3D Coin */}
        <button onClick={() => onSelect("center")} className="flex flex-col items-center relative -mt-6">
          <div className="relative">
            <div className="absolute inset-0 rounded-full opacity-70"
              style={{ background: "radial-gradient(circle,#d4a01766 0%,transparent 70%)", transform: "scale(1.4)" }} />
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg,#ffe87a,#d4a017,#7a4500)",
                boxShadow: "0 0 28px #d4a017bb, 0 4px 16px #000a, inset 0 2px 6px #ffffff44",
                border: "2.5px solid #ffe87a88",
              }}
            >
              <Coin3D size={46} />
            </div>
          </div>
          <span style={{ fontFamily: "Outfit", fontWeight: 700, fontSize: 9, color: "#d4a017", marginTop: 2 }}>Live</span>
        </button>

        {/* Message */}
        <button onClick={() => onSelect("message")} className="flex flex-col items-center gap-0.5">
          <MessageIcon active={active === "message"} count={10} />
          <span style={{ fontFamily: "Outfit", fontWeight: 700, fontSize: 9, color: active === "message" ? "#d4a017" : "#6b7280" }}>Message</span>
        </button>

        {/* Profile */}
        <button onClick={() => onSelect("my")} className="flex flex-col items-center gap-0.5">
          <MoonIcon active={active === "my"} />
          <span style={{ fontFamily: "Outfit", fontWeight: 700, fontSize: 9, color: active === "my" ? "#d4a017" : "#6b7280" }}>Profile</span>
        </button>
      </div>
    </div>
  );
}

// ─── Room Interior Screen ─────────────────────────────────────────────────────

const GIFT_PANEL_ITEMS = [
  { id: 1,  name: "Rose",       coins: 1,    emoji: "🌹" },
  { id: 2,  name: "Lollipop",   coins: 10,   emoji: "🍭" },
  { id: 3,  name: "Ring",       coins: 99,   emoji: "💍" },
  { id: 4,  name: "Crown",      coins: 199,  emoji: "👑" },
  { id: 5,  name: "Diamond",    coins: 500,  emoji: "💎" },
  { id: 6,  name: "Sports Car", coins: 1000, emoji: "🏎️" },
  { id: 7,  name: "Castle",     coins: 5000, emoji: "🏰" },
  { id: 8,  name: "Galaxy",     coins: 9999, emoji: "🌌" },
  { id: 9,  name: "Rocket",     coins: 299,  emoji: "🚀" },
  { id: 10, name: "Trophy",     coins: 699,  emoji: "🏆" },
  { id: 11, name: "Firework",   coins: 88,   emoji: "🎆" },
  { id: 12, name: "Yacht",      coins: 3999, emoji: "🛥️" },
];


/** Mosque + crescent green background — matches screenshot */
function MosqueBg() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Rich dark green base */}
      <div className="absolute inset-0"
        style={{background:"linear-gradient(180deg,#001c08 0%,#003010 25%,#002a0d 55%,#001408 80%,#000a04 100%)"}} />

      {/* Bokeh glow spots */}
      <div className="absolute" style={{top:"10%",left:"10%",width:180,height:180,
        background:"radial-gradient(circle,#15803d22 0%,transparent 70%)",borderRadius:"50%"}} />
      <div className="absolute" style={{top:"30%",right:"5%",width:140,height:140,
        background:"radial-gradient(circle,#16a34a18 0%,transparent 70%)",borderRadius:"50%"}} />

      {/* Stars */}
      {[
        {x:6,y:8,s:2.5},{x:18,y:5,s:1.5},{x:35,y:10,s:2},{x:58,y:6,s:1.5},{x:72,y:9,s:2.5},
        {x:85,y:4,s:1.5},{x:92,y:14,s:2},{x:10,y:22,s:1.5},{x:45,y:18,s:1.5},{x:78,y:20,s:2},
        {x:3,y:38,s:1.5},{x:25,y:42,s:2},{x:50,y:35,s:1.5},{x:88,y:40,s:1.5},{x:15,y:55,s:2},
        {x:40,y:60,s:1.5},{x:65,y:52,s:2.5},{x:5,y:70,s:1.5},{x:30,y:72,s:2},
      ].map((s,i)=>(
        <div key={i} className="absolute rounded-full"
          style={{left:`${s.x}%`,top:`${s.y}%`,width:s.s,height:s.s,background:"#fff",
            opacity:0.25+i*0.015,animation:`pulse ${1.8+i*0.18}s ease-in-out infinite`,
            animationDelay:`${i*0.15}s`}} />
      ))}

      {/* Large crescent moon — center-right */}
      <div className="absolute" style={{right:"12%",top:"32%",opacity:0.22}}>
        <svg width="100" height="120" viewBox="0 0 100 120" fill="none">
          <path d="M68 12 A46 46 0 1 0 68 108 A34 34 0 1 1 68 12Z" fill="#86efac"/>
        </svg>
      </div>

      {/* Sparkle cross — center */}
      <div className="absolute" style={{right:"28%",top:"46%",opacity:0.35}}>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="white">
          <path d="M8 0 L9 7 L16 8 L9 9 L8 16 L7 9 L0 8 L7 7 Z"/>
        </svg>
      </div>

      {/* Mosque silhouette — right side, large */}
      <div className="absolute" style={{right:0,bottom:0,opacity:0.22}}>
        <svg viewBox="0 0 220 340" width="220" height="340" fill="#15803d">
          {/* Base */}
          <rect x="0" y="300" width="220" height="40"/>
          {/* Main minaret — tall right */}
          <rect x="155" y="60" width="28" height="248"/>
          <ellipse cx="169" cy="60" rx="18" ry="28"/>
          <rect x="163" y="35" width="12" height="28"/>
          <ellipse cx="169" cy="35" rx="8" ry="12"/>
          <rect x="166" y="22" width="6" height="15"/>
          {/* Crescent finial */}
          <path d="M163 20 A7 7 0 1 0 175 20 A5 5 0 1 1 163 20Z" fill="#d4a017" opacity="0.7"/>
          {/* Main dome */}
          <ellipse cx="90" cy="190" rx="52" ry="50"/>
          <rect x="38" y="190" width="104" height="110"/>
          {/* Side dome */}
          <ellipse cx="30" cy="230" rx="30" ry="28"/>
          <rect x="0" y="230" width="60" height="70"/>
          {/* Arch windows */}
          <rect x="72" y="240" width="18" height="32" rx="9" fill="#001c08"/>
          <rect x="98" y="240" width="18" height="32" rx="9" fill="#001c08"/>
          <rect x="12" y="248" width="14" height="24" rx="7" fill="#001c08"/>
          {/* Left small minaret */}
          <rect x="4" y="150" width="16" height="150"/>
          <ellipse cx="12" cy="150" rx="10" ry="16"/>
          <rect x="8" y="134" width="8" height="18"/>
          <path d="M7 132 A5 5 0 1 0 17 132 A4 4 0 1 1 7 132Z" fill="#d4a017" opacity="0.6"/>
          {/* Decorative arches on facade */}
          <rect x="44" y="205" width="14" height="24" rx="7" fill="#001c08"/>
          <rect x="122" y="205" width="14" height="24" rx="7" fill="#001c08"/>
          {/* Gold dome tip */}
          <path d="M82 140 A9 9 0 1 0 98 140 A7 7 0 1 1 82 140Z" fill="#d4a017" opacity="0.5"/>
        </svg>
      </div>

      {/* Bottom dark vignette */}
      <div className="absolute bottom-0 left-0 right-0 h-40"
        style={{background:"linear-gradient(180deg,transparent,rgba(0,8,3,0.7))"}} />
    </div>
  );
}

/** Gold ornate circular frame — unique gradient IDs per instance */
function GoldSeatFrame({ size, children, speaking, uid }: {
  size: number; children: React.ReactNode; speaking?: boolean; uid: string;
}) {
  const r = size / 2;
  const outerR = r - 2;
  const innerR = r - 8;
  return (
    <div className="relative flex items-center justify-center" style={{width:size,height:size}}>
      {/* Pulsing glow when speaking */}
      {speaking && (
        <div className="absolute rounded-full animate-pulse"
          style={{inset:-4,background:"rgba(212,160,23,0.35)",boxShadow:"0 0 18px #d4a01788"}} />
      )}
      {/* Gold SVG ring */}
      <svg className="absolute inset-0" width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <defs>
          <linearGradient id={`gf_o_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%"   stopColor="#fff176"/>
            <stop offset="30%"  stopColor="#d4a017"/>
            <stop offset="65%"  stopColor="#ffd700"/>
            <stop offset="100%" stopColor="#7a4a00"/>
          </linearGradient>
          <linearGradient id={`gf_i_${uid}`} x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%"   stopColor="#ffd70099"/>
            <stop offset="100%" stopColor="#d4a01744"/>
          </linearGradient>
        </defs>
        {/* Outer gold ring */}
        <circle cx={r} cy={r} r={outerR} stroke={`url(#gf_o_${uid})`} strokeWidth="3.5" fill="none"/>
        {/* Inner accent ring */}
        <circle cx={r} cy={r} r={innerR} stroke={`url(#gf_i_${uid})`} strokeWidth="1.2" fill="none" opacity="0.8"/>
        {/* Gold dots at N/E/S/W */}
        {[0,90,180,270].map((deg,idx)=>{
          const rad=(deg*Math.PI)/180;
          const dx=r+(outerR)*Math.sin(rad);
          const dy=r-(outerR)*Math.cos(rad);
          return <circle key={idx} cx={dx} cy={dy} r="3" fill="#ffd700" opacity="0.95"/>;
        })}
        {/* Diagonal small dots */}
        {[45,135,225,315].map((deg,idx)=>{
          const rad=(deg*Math.PI)/180;
          const dx=r+(outerR)*Math.sin(rad);
          const dy=r-(outerR)*Math.cos(rad);
          return <circle key={`d${idx}`} cx={dx} cy={dy} r="1.8" fill="#d4a017" opacity="0.7"/>;
        })}
      </svg>
      {/* Inner circle content */}
      <div className="absolute rounded-full overflow-hidden flex items-center justify-center"
        style={{
          inset:11,
          background: speaking
            ? "radial-gradient(circle,#1a4a08,#0a2a04)"
            : "radial-gradient(circle,#0f3d14,#052008)",
          boxShadow: speaking ? "inset 0 0 12px #d4a01733" : "none",
        }}>
        {children}
      </div>
    </div>
  );
}

/** Gold throne SVG — unique gradient IDs */
function GoldThrone({ size=34, uid="" }: { size?: number; uid?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id={`th_a_${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%"   stopColor="#fff176"/>
          <stop offset="45%"  stopColor="#d4a017"/>
          <stop offset="100%" stopColor="#7a4a00"/>
        </linearGradient>
        <linearGradient id={`th_b_${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#e8b820"/>
          <stop offset="100%" stopColor="#8a5c00"/>
        </linearGradient>
      </defs>
      {/* Legs */}
      <rect x="11" y="37" width="5" height="9" rx="2"  fill={`url(#th_a_${uid})`}/>
      <rect x="32" y="37" width="5" height="9" rx="2"  fill={`url(#th_a_${uid})`}/>
      {/* Seat */}
      <rect x="8"  y="29" width="32" height="10" rx="3" fill={`url(#th_a_${uid})`}/>
      {/* Back */}
      <rect x="10" y="11" width="28" height="20" rx="3" fill={`url(#th_b_${uid})`}/>
      {/* Crown spikes */}
      <path d="M10 11 L14 5 L24 10 L34 5 L38 11Z" fill={`url(#th_a_${uid})`}/>
      {/* Armrests */}
      <rect x="6"  y="25" width="5" height="9" rx="2" fill={`url(#th_a_${uid})`}/>
      <rect x="37" y="25" width="5" height="9" rx="2" fill={`url(#th_a_${uid})`}/>
      {/* Shine */}
      <rect x="14" y="13" width="9" height="4" rx="2" fill="white" opacity="0.18"/>
    </svg>
  );
}

/** Gold microphone SVG */
function GoldMic({ size=34, uid="" }: { size?: number; uid?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id={`mc_a_${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%"   stopColor="#fff176"/>
          <stop offset="50%"  stopColor="#d4a017"/>
          <stop offset="100%" stopColor="#7a4a00"/>
        </linearGradient>
      </defs>
      {/* Body */}
      <rect x="17" y="4" width="14" height="22" rx="7" fill={`url(#mc_a_${uid})`}/>
      {/* Grille lines */}
      <rect x="19" y="9"  width="10" height="1.5" rx="0.75" fill="white" opacity="0.22"/>
      <rect x="19" y="13" width="10" height="1.5" rx="0.75" fill="white" opacity="0.22"/>
      <rect x="19" y="17" width="10" height="1.5" rx="0.75" fill="white" opacity="0.22"/>
      {/* Stand arc */}
      <path d="M12 23 Q12 36 24 36 Q36 36 36 23"
        stroke={`url(#mc_a_${uid})`} strokeWidth="3" fill="none" strokeLinecap="round"/>
      {/* Pole + base */}
      <rect x="22" y="36" width="4" height="7"  fill={`url(#mc_a_${uid})`}/>
      <rect x="14" y="42" width="20" height="3" rx="1.5" fill={`url(#mc_a_${uid})`}/>
      {/* Shine */}
      <ellipse cx="20" cy="9" rx="3" ry="4" fill="white" opacity="0.2"/>
    </svg>
  );
}

/** Gift send panel */
function GiftPanel({ onClose }: { onClose: () => void }) {
  const [selected, setSelected] = useState(0);
  const [tab, setTab]           = useState<"gifts"|"lucky">("gifts");
  const [qty, setQty]           = useState(1);

  return (
    <div className="rounded-t-3xl overflow-hidden"
      style={{background:"linear-gradient(180deg,#0a2a10,#040f06)",
        border:"1.5px solid #22c55e33",boxShadow:"0 -8px 40px #22c55e33",maxHeight:"62%"}}>
      <div className="flex justify-center pt-2 pb-1">
        <div className="w-10 h-1 rounded-full bg-white/20"/>
      </div>
      {/* Tab bar */}
      <div className="flex items-center px-4 gap-4 pb-2 border-b border-white/10">
        {(["gifts","lucky"] as const).map(t=>(
          <button key={t} onClick={()=>setTab(t)}
            className="pb-1.5 text-sm font-bold relative"
            style={{fontFamily:"Outfit",color:tab===t?"#fff":"#6b7280"}}>
            {t==="gifts"?"🎁 Gifts":"🍀 Lucky"}
            {tab===t&&<div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
              style={{background:"linear-gradient(90deg,#d4a017,#22c55e)"}}/>}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-1">
          <Coin3D size={14}/><span style={{fontFamily:"Outfit",fontWeight:700,fontSize:11,color:"#d4a017"}}>4,820</span>
        </div>
        <button onClick={onClose} className="text-white/40 text-xl ml-2 leading-none">✕</button>
      </div>

      {tab==="gifts"?(
        <>
          <div className="grid grid-cols-4 gap-2 px-3 py-3 overflow-y-auto" style={{maxHeight:210}}>
            {GIFT_PANEL_ITEMS.map((g,i)=>(
              <button key={g.id} onClick={()=>setSelected(i)}
                className="flex flex-col items-center gap-0.5 py-2 rounded-xl transition-all"
                style={{
                  background:selected===i?"linear-gradient(135deg,#d4a01722,#22c55e18)":"rgba(255,255,255,0.04)",
                  border:selected===i?"1.5px solid #d4a017":"1.5px solid rgba(255,255,255,0.06)",
                  boxShadow:selected===i?"0 0 10px #d4a01744":"none",
                }}>
                <div className="relative">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center"
                    style={{background:selected===i?"rgba(212,160,23,0.12)":"rgba(255,255,255,0.05)",fontSize:24}}>
                    {g.emoji}
                  </div>
                  {selected===i&&<div className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center"
                    style={{background:"#d4a017",fontSize:8,color:"#0f0f1a",fontWeight:900}}>✓</div>}
                </div>
                <span style={{fontFamily:"Outfit",fontSize:8,color:"#ffffffbb",fontWeight:600}}>{g.name}</span>
                <div className="flex items-center gap-0.5">
                  <Coin3D size={9}/><span style={{fontFamily:"Outfit",fontSize:8,color:"#d4a017",fontWeight:700}}>{g.coins}</span>
                </div>
              </button>
            ))}
          </div>
          {/* Send bar */}
          <div className="px-4 py-3 flex items-center gap-3 border-t border-white/8">
            <div className="flex gap-0.5 bg-white/5 rounded-full px-1.5 py-1">
              {[1,5,10,99].map(q=>(
                <button key={q} onClick={()=>setQty(q)}
                  className="w-7 h-7 rounded-full text-xs font-black"
                  style={{fontFamily:"Outfit",
                    background:qty===q?"linear-gradient(135deg,#d4a017,#22c55e)":"transparent",
                    color:qty===q?"#0f0f1a":"#6b7280"}}>
                  {q}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1.5 flex-1">
              <span style={{fontSize:18}}>{GIFT_PANEL_ITEMS[selected]?.emoji}</span>
              <div>
                <p style={{fontFamily:"Outfit",fontSize:10,color:"#fff",fontWeight:700}}>{GIFT_PANEL_ITEMS[selected]?.name}</p>
                <div className="flex items-center gap-0.5">
                  <Coin3D size={9}/><span style={{fontFamily:"Outfit",fontSize:9,color:"#d4a017",fontWeight:700}}>
                    {(GIFT_PANEL_ITEMS[selected]?.coins??0)*qty}
                  </span>
                </div>
              </div>
            </div>
            <button className="px-5 py-2.5 rounded-2xl font-black text-sm"
              style={{fontFamily:"Outfit",background:"linear-gradient(135deg,#d4a017,#22c55e)",
                color:"#0f0f1a",boxShadow:"0 4px 16px #d4a01766"}}>
              Send 🎁
            </button>
          </div>
        </>
      ):(
        <div className="flex flex-col items-center justify-center py-10 gap-3">
          <span style={{fontSize:44}}>🍀</span>
          <p style={{fontFamily:"Outfit",fontWeight:800,fontSize:16,color:"#fff"}}>Lucky Draw</p>
          <p style={{fontFamily:"Nunito",fontSize:12,color:"#ffffff66"}}>Spin to win exclusive gifts!</p>
          <button className="mt-2 px-8 py-3 rounded-2xl font-black"
            style={{fontFamily:"Outfit",background:"linear-gradient(135deg,#d4a017,#b8860b)",
              color:"#0f0f1a",boxShadow:"0 4px 16px #d4a01766"}}>
            Spin — 100 🪙
          </button>
        </div>
      )}
    </div>
  );
}

function RoomScreen({ onBack }: { onBack: () => void }) {
  const [chatTab,   setChatTab]   = useState<"all"|"chat">("all");
  const [showGifts, setShowGifts] = useState(false);
  const [speakIdx,  setSpeakIdx]  = useState(1);

  useEffect(()=>{
    const t = setInterval(()=>setSpeakIdx(p=>p===1?5:1), 2600);
    return ()=>clearInterval(t);
  },[]);

  const SEATS = [
    {label:"Host",       avatar:null,                                                                                    isHost:true },
    {label:"Mr.↓Raj★",  avatar:"https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=80&h=80&fit=crop",       isHost:false},
    {label:"No.3",       avatar:null,                                                                                    isHost:false},
    {label:"No.4",       avatar:null,                                                                                    isHost:false},
    {label:"No.5",       avatar:null,                                                                                    isHost:false},
    {label:"No.6",       avatar:null,                                                                                    isHost:false},
    {label:"No.7",       avatar:null,                                                                                    isHost:false},
    {label:"No.8",       avatar:null,                                                                                    isHost:false},
  ];

  return (
    <div className="relative w-full h-full flex flex-col overflow-hidden">
      <MosqueBg/>

      {/* ── Top bar ── */}
      <div className="relative z-10 flex items-center justify-between px-3 pt-9 pb-1.5 shrink-0">
        {/* Left */}
        <div className="flex items-center gap-1.5 min-w-0">
          <button onClick={onBack}
            className="w-7 h-7 rounded-full flex items-center justify-center shrink-0"
            style={{background:"rgba(0,0,0,0.45)"}}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
              <path d="M15 18l-6-6 6-6" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
            </svg>
          </button>
          <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&h=60&fit=crop"
            alt="host" className="w-10 h-10 rounded-full object-cover shrink-0"
            style={{border:"2px solid #d4a017"}}/>
          <div className="min-w-0">
            <div className="flex items-center gap-1">
              <span className="font-black text-white truncate" style={{fontFamily:"Outfit",fontSize:13,maxWidth:110}}>
                Listen to music c...
              </span>
              <div className="w-6 h-6 rounded-full shrink-0 flex items-center justify-center"
                style={{background:"linear-gradient(135deg,#ec4899,#be185d)",boxShadow:"0 0 8px #ec489977"}}>
                <span style={{fontSize:11}}>🩷</span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <span style={{fontSize:9}}>🏠</span>
              <span style={{fontFamily:"Outfit",fontSize:9,color:"rgba(255,255,255,0.55)"}}>ID:10024210</span>
            </div>
          </div>
        </div>
        {/* Right icons */}
        <div className="flex items-center gap-2 shrink-0">
          {[
            <svg key="f" width="14" height="14" viewBox="0 0 24 24" fill="white" opacity="0.85">
              <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
              <line x1="4" y1="22" x2="4" y2="15" stroke="white" strokeWidth="2"/>
            </svg>,
            <svg key="r" width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M1 4v6h6" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.85"/>
              <path d="M3.51 15a9 9 0 102.13-9.36L1 10" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.85"/>
            </svg>,
            <svg key="p" width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M18.36 6.64A9 9 0 0121 12a9 9 0 01-9 9 9 9 0 01-9-9 9 9 0 012.64-6.36" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.85"/>
              <path d="M12 2v10" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.85"/>
            </svg>,
          ].map((icon,i)=>(
            <button key={i} className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{background:"rgba(0,0,0,0.4)"}}>
              {icon}
            </button>
          ))}
        </div>
      </div>

      {/* ── Controls row ── */}
      <div className="relative z-10 flex items-center justify-between px-4 mb-1.5 shrink-0">
        <div className="flex items-center gap-2.5">
          <button className="w-8 h-8 rounded-full flex items-center justify-center" style={{background:"rgba(0,0,0,0.4)"}}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="white" opacity="0.8">
              <path d="M11 5L6 9H2v6h4l5 4V5z"/>
            </svg>
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1 rounded-full"
            style={{background:"rgba(0,0,0,0.4)",border:"1px solid rgba(255,255,255,0.08)"}}>
            <span style={{fontSize:13}}>🔥</span>
            <span style={{fontFamily:"Outfit",fontWeight:700,fontSize:11,color:"#fff"}}>0</span>
          </button>
        </div>
        <button className="flex items-center gap-1 px-2.5 py-1 rounded-full"
          style={{background:"rgba(0,0,0,0.4)"}}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none"/>
            <circle cx="9" cy="7" r="4" stroke="white" strokeWidth="2" fill="none"/>
            <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" stroke="white" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <span style={{fontFamily:"Outfit",fontWeight:700,fontSize:10,color:"#fff"}}>1</span>
        </button>
      </div>

      {/* ── Mic seats 2×4 ── */}
      <div className="relative z-10 grid grid-cols-4 gap-x-0 gap-y-2 px-2 mb-2 shrink-0">
        {SEATS.map((seat,i)=>{
          const speaking = i===speakIdx;
          return (
            <div key={i} className="flex flex-col items-center gap-0.5">
              <GoldSeatFrame size={66} speaking={speaking} uid={`s${i}`}>
                {seat.avatar ? (
                  <img src={seat.avatar} alt={seat.label} className="w-full h-full object-cover rounded-full"/>
                ) : seat.isHost ? (
                  <GoldMic size={32} uid={`m${i}`}/>
                ) : (
                  <GoldThrone size={32} uid={`t${i}`}/>
                )}
              </GoldSeatFrame>
              {/* Name */}
              <div className="flex items-center gap-0.5 max-w-[72px]">
                {i===1&&<span style={{fontSize:8}}>🏠</span>}
                <span className="truncate text-center block"
                  style={{fontFamily:"Nunito",fontSize:9,fontWeight:i===1?700:400,
                    color:i===1?"#fff":"rgba(255,255,255,0.7)",maxWidth:64}}>
                  {seat.label}{i===1?" ★ ...":""}
                </span>
              </div>
              {/* Heart count */}
              <div className="flex items-center gap-0.5">
                <span style={{fontSize:8,color:"#f9a8d4"}}>❤</span>
                <span style={{fontFamily:"Outfit",fontSize:8,color:"rgba(255,255,255,0.45)",fontWeight:600}}>0</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── All / Chat tabs ── */}
      <div className="relative z-10 flex items-center gap-4 px-4 shrink-0"
        style={{borderBottom:"1px solid rgba(255,255,255,0.1)"}}>
        {(["all","chat"] as const).map(t=>(
          <button key={t} onClick={()=>setChatTab(t)}
            className="pb-1.5 pt-0.5 font-bold text-sm relative"
            style={{fontFamily:"Outfit",color:chatTab===t?"#fff":"rgba(255,255,255,0.4)"}}>
            {t==="all"?"All":"Chat"}
            {chatTab===t&&<div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white"/>}
          </button>
        ))}
        <div className="ml-auto w-8 h-1 rounded-full bg-white/20 mb-1"/>
      </div>

      {/* ── Chat feed (scrollable, fills remaining space) ── */}
      <div className="relative z-10 flex-1 overflow-y-auto px-3 py-2 flex flex-col gap-2 pb-20"
        style={{scrollbarWidth:"none"}}>

        {/* Official announcement — yellow text, semi-transparent card */}
        <div className="p-3 rounded-xl"
          style={{background:"rgba(0,0,0,0.42)",border:"1px solid rgba(34,197,94,0.12)"}}>
          <p style={{fontFamily:"Nunito",fontSize:11,color:"#fde047",lineHeight:1.55}}>
            Official announcement: APP advocates civilized chatting and making friends.
            If the room name, cover, content, and comments contain vulgarity, temptation,
            and politics, etc., you will be punished; beware of fraudulent behavior such as
            depositing value on behalf of you, protect property safety, and avoid losses;
            inspectors conduct 24-hour online inspections
          </p>
        </div>

        {/* Room announcement */}
        <div className="p-3 rounded-xl" style={{background:"rgba(0,0,0,0.32)"}}>
          <p style={{fontFamily:"Nunito",fontSize:11,lineHeight:1.5}}>
            <span style={{color:"#fde047",fontWeight:700}}>Room announcement:</span>
            <span style={{color:"#fff"}}> ztrfdsewajugtreshuij</span>
          </p>
        </div>

        {/* Ask followers */}
        <div className="flex items-center justify-between p-3 rounded-xl"
          style={{background:"rgba(0,0,0,0.32)"}}>
          <p style={{fontFamily:"Nunito",fontSize:11,color:"rgba(255,255,255,0.85)",lineHeight:1.45}}>
            Ask your followers to support to make the room more popular
          </p>
          <button className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 ml-2"
            style={{background:"rgba(255,255,255,0.1)"}}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="white" opacity="0.75">
              <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
              <line x1="4" y1="22" x2="4" y2="15" stroke="white" strokeWidth="2"/>
            </svg>
          </button>
        </div>

        {/* Enter notification — gradient name */}
        <div className="self-start px-3 py-1.5 rounded-full"
          style={{background:"rgba(0,0,0,0.3)"}}>
          <span>
            <span style={{fontFamily:"Nunito",fontWeight:700,fontSize:11,
              background:"linear-gradient(90deg,#f9a8d4,#c084fc,#818cf8)",
              WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>
              Mr.↓Raj★ 🍒 🦢
            </span>
            <span style={{fontFamily:"Nunito",fontSize:11,color:"rgba(255,255,255,0.85)"}}> enters the room</span>
          </span>
        </div>

        {/* Topics share */}
        <div className="flex items-center justify-between p-3 rounded-xl"
          style={{background:"rgba(0,0,0,0.32)"}}>
          <span style={{fontFamily:"Nunito",fontSize:11,color:"rgba(255,255,255,0.85)"}}>
            Topics share with everyone
          </span>
          <button className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ml-2"
            style={{background:"rgba(255,255,255,0.1)"}}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"
                stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <path d="M15 3h6v6M10 14L21 3"
                stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        {/* Winner banner — purple→blue gradient */}
        <div className="rounded-2xl overflow-hidden flex items-stretch"
          style={{background:"linear-gradient(125deg,#7c3aed 0%,#3b82f6 55%,#06b6d4 100%)",
            border:"1px solid rgba(167,139,250,0.35)",boxShadow:"0 0 18px #7c3aed44",minHeight:62}}>
          <div className="flex-1 px-3 py-2.5 flex flex-col justify-center">
            <div className="flex items-center gap-2 flex-wrap">
              <span style={{fontSize:15}}>🎣</span>
              <span style={{fontFamily:"Outfit",fontWeight:800,fontSize:12,color:"#fff"}}>
                Ame***won $5 x 1
              </span>
              <span style={{fontFamily:"Outfit",fontWeight:700,fontSize:12,color:"#fde047",textDecoration:"underline"}}>
                Try&gt;
              </span>
            </div>
          </div>
          {/* $5 money graphic */}
          <div className="w-20 flex items-center justify-center relative shrink-0">
            <div className="absolute inset-0"
              style={{background:"radial-gradient(circle at 40% 40%,rgba(255,255,255,0.18),transparent 65%)"}}/>
            <div className="flex flex-col items-center">
              <span style={{fontSize:26,filter:"drop-shadow(0 2px 8px #000a)"}}>💵</span>
              <div className="px-2 py-0.5 rounded-full -mt-1"
                style={{background:"linear-gradient(135deg,#16a34a,#15803d)",boxShadow:"0 2px 8px #16a34a88"}}>
                <span style={{fontFamily:"Outfit",fontWeight:900,fontSize:11,color:"#fff"}}>$5</span>
              </div>
            </div>
          </div>
        </div>

        {/* Extra chat */}
        {[
          {user:"StarQueen",flag:"🇮🇳",text:"Hello everyone! 🌟",  col:"#86efac"},
          {user:"NeonKing", flag:"🇵🇰",text:"This room is fire 🔥",col:"#fda4af"},
          {user:"AuroraV",  flag:"🇮🇳",text:"Sending gifts 🎁💎",  col:"#c4b5fd"},
        ].map((m,i)=>(
          <div key={i} className="flex items-start gap-2">
            <div className="w-6 h-6 rounded-full shrink-0 flex items-center justify-center"
              style={{background:"rgba(255,255,255,0.08)",border:"1px solid rgba(255,255,255,0.12)"}}>
              <span style={{fontSize:10,color:"#fff",fontWeight:700,fontFamily:"Outfit"}}>{m.user[0]}</span>
            </div>
            <p style={{fontFamily:"Nunito",fontSize:11,color:"rgba(255,255,255,0.85)",lineHeight:1.4}}>
              <span style={{color:m.col,fontWeight:700}}>{m.flag} {m.user}: </span>{m.text}
            </p>
          </div>
        ))}
      </div>

      {/* ── Right floating widgets ── */}
      <div className="absolute right-2 z-30 flex flex-col gap-2" style={{top:200}}>
        {/* Rocket */}
        <div className="flex flex-col items-center gap-0">
          <span style={{fontSize:24,filter:"drop-shadow(0 2px 6px #000a)"}}>🚀</span>
          <div className="px-2 py-0.5 rounded-full -mt-1"
            style={{background:"#d4a017",boxShadow:"0 0 8px #d4a01766"}}>
            <span style={{fontFamily:"Outfit",fontWeight:800,fontSize:9,color:"#0f0f1a"}}>0%</span>
          </div>
        </div>

        {/* Campfire globe */}
        <div className="rounded-2xl overflow-hidden"
          style={{width:60,background:"linear-gradient(160deg,#1a0800,#2d1200)",
            border:"1.5px solid #d4a01766",boxShadow:"0 0 14px #d4a01733"}}>
          <div className="flex justify-center pt-1.5 pb-1">
            <div className="w-11 h-11 rounded-full overflow-hidden flex items-center justify-center"
              style={{background:"radial-gradient(circle,#7c2d12,#3d0d00)"}}>
              <span style={{fontSize:26}}>🔥</span>
            </div>
          </div>
          <div className="flex items-center justify-center gap-0.5 pb-2">
            <span style={{fontSize:10}}>⭐</span>
            <span style={{fontFamily:"Outfit",fontWeight:900,fontSize:11,color:"#d4a017"}}>6970</span>
          </div>
        </div>

        {/* Family Oil Tycoon */}
        <div className="rounded-xl overflow-hidden"
          style={{width:60,border:"1px solid #b45309aa"}}>
          <div className="flex flex-col items-center justify-center px-1 py-2"
            style={{background:"linear-gradient(135deg,#92400e,#451a03)",minHeight:52}}>
            <span style={{fontSize:13}}>🛢️</span>
            <span style={{fontFamily:"Outfit",fontWeight:900,fontSize:7,color:"#fde047",letterSpacing:0.2,textAlign:"center",lineHeight:1.3}}>
              Family{"\n"}Oil Tycoon
            </span>
          </div>
          <div className="flex justify-center gap-1 py-1" style={{background:"#1c0a00"}}>
            {[0,1,2].map(i=>(
              <div key={i} className="rounded-full"
                style={{width:i===0?14:5,height:5,
                  background:i===0?"#d4a017":"rgba(255,255,255,0.22)"}}/>
            ))}
          </div>
        </div>
      </div>

      {/* ── Bottom action bar ── */}
      <div className="absolute bottom-0 left-0 right-0 z-40 shrink-0"
        style={{background:"linear-gradient(180deg,transparent,rgba(0,8,3,0.97) 30%,rgba(0,6,2,1))"}}>
        <div className="flex items-center justify-between px-3 py-2.5" style={{paddingBottom:16}}>
          {/* WhatsApp bubble */}
          <button className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{background:"rgba(255,255,255,0.07)"}}>
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none">
              <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"
                stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.82"/>
            </svg>
          </button>
          {/* Mic */}
          <button className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{background:"rgba(255,255,255,0.07)"}}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M12 2C10.3 2 9 3.3 9 5v7c0 1.7 1.3 3 3 3s3-1.3 3-3V5c0-1.7-1.3-3-3-3z" fill="white" opacity="0.82"/>
              <path d="M19 10v2c0 3.9-3.1 7-7 7s-7-3.1-7-7v-2" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.7"/>
              <path d="M12 19v3M9 22h6" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.6"/>
            </svg>
          </button>
          {/* Emoji */}
          <button className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{background:"rgba(255,255,255,0.07)"}}>
            <span style={{fontSize:20}}>😊</span>
          </button>
          {/* Center gift — colorful green/gold gift wrapped box */}
          <button onClick={()=>setShowGifts(true)}
            className="w-14 h-14 rounded-full flex items-center justify-center relative"
            style={{background:"linear-gradient(135deg,#16a34a,#d4a017,#16a34a)",
              boxShadow:"0 0 22px #22c55e77,0 0 12px #d4a01755,0 4px 14px #000a",
              border:"2.5px solid rgba(250,240,100,0.45)"}}>
            <div className="absolute inset-0 rounded-full"
              style={{background:"radial-gradient(circle at 35% 28%,rgba(255,255,255,0.28),transparent 58%)"}}/>
            <GiftBox size={36}/>
          </button>
          {/* Gamepad */}
          <button className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{background:"rgba(255,255,255,0.07)"}}>
            <span style={{fontSize:20}}>🎮</span>
          </button>
          {/* Bell + badge */}
          <button className="relative w-10 h-10 rounded-full flex items-center justify-center"
            style={{background:"rgba(255,255,255,0.07)"}}>
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none">
              <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"
                stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.82"/>
              <path d="M13.73 21a2 2 0 01-3.46 0"
                stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.7"/>
            </svg>
            <div className="absolute -top-1 -right-0.5 w-5 h-5 rounded-full flex items-center justify-center"
              style={{background:"#ef4444",border:"2px solid rgba(0,6,2,1)"}}>
              <span style={{fontFamily:"Outfit",fontSize:9,fontWeight:800,color:"#fff"}}>4</span>
            </div>
          </button>
          {/* Grid */}
          <button className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{background:"rgba(255,255,255,0.07)"}}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
              <rect x="3"  y="3"  width="7" height="7" rx="1.5" fill="white" opacity="0.75"/>
              <rect x="14" y="3"  width="7" height="7" rx="1.5" fill="white" opacity="0.75"/>
              <rect x="3"  y="14" width="7" height="7" rx="1.5" fill="white" opacity="0.75"/>
              <rect x="14" y="14" width="7" height="7" rx="1.5" fill="white" opacity="0.75"/>
            </svg>
          </button>
        </div>
      </div>

      {/* ── Gift panel overlay ── */}
      {showGifts&&(
        <>
          <div className="absolute inset-0 z-40 bg-black/55" onClick={()=>setShowGifts(false)}/>
          <div className="absolute inset-x-0 bottom-0 z-50">
            <GiftPanel onClose={()=>setShowGifts(false)}/>
          </div>
        </>
      )}
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [navActive, setNavActive] = useState<NavKey>("party");
  const [pageTab, setPageTab] = useState<PageTab>("party");
  const [filter, setFilter] = useState<"popular" | "new">("popular");
  const [screen, setScreen] = useState<"home" | "room">("home");

  return (
    <div className="flex items-center justify-center w-full h-full" style={{ background: "#030805" }}>
      <div
        className="relative overflow-hidden"
        style={{ width: 390, height: "100%", maxHeight: 844, background: "#08100a" }}
      >
        {screen === "room" ? (
          <RoomScreen onBack={() => setScreen("home")} />
        ) : (
          <>
            {/* Subtle ambient glows */}
            <div className="absolute pointer-events-none"
              style={{ top: -40, left: -40, width: 200, height: 200, background: "radial-gradient(circle,#d4a01710 0%,transparent 70%)" }} />
            <div className="absolute pointer-events-none"
              style={{ top: 300, right: -30, width: 150, height: 150, background: "radial-gradient(circle,#22c55e0c 0%,transparent 70%)" }} />

            {/* Scrollable content */}
            <div className="overflow-y-auto h-full pb-28" style={{ scrollbarWidth: "none" }}>
              <TopHeader active={pageTab} onSelect={setPageTab} />
              <BannerCarousel />
              <RankingCards />
              <FilterPills active={filter} onSelect={setFilter} />
              <RoomGrid rooms={ROOMS} onEnter={() => setScreen("room")} />
              <FamilyRoomRow />
            </div>

            <BottomNav active={navActive} onSelect={setNavActive} />
          </>
        )}
      </div>
    </div>
  );
}
